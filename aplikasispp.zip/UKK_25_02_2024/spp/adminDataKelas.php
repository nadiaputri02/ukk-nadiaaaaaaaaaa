<?php
require 'config.php';

session_start();

// mencari data kelas
$data = array();
$sql = "SELECT *
        FROM kelas
        ORDER BY nama_kelas DESC;";
$result = $conn->query($sql);
if ($result->num_rows > 0) {
    // Fetch associative array
    $i = 0;
    while ($row = $result->fetch_assoc()) {
        $data[$i] = $row;
        $i++;
    }
}
// var_dump($data);

$title = 'Kelas';
$active = 'kelas';
include 'views/admin/kelas.php';

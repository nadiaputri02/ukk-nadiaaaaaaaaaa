<?php
require 'config.php';
session_start();
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $id_petugas = $_SESSION['id'];
    $siswa = $_POST['siswa'];
    $tgl_bayar = $_POST['tgl_bayar'];
    $jumlah_bayar = $_POST['jumlah_bayar'];
    // var_dump($id_petugas, $siswa, $tgl_bayar, $jumlah_bayar);

    // menambahkan data
    $sql = "INSERT INTO pembayaran (id_petugas, NIS, tgl_bayar, jumlah_bayar) VALUES ('$id_petugas','$siswa','$tgl_bayar','$jumlah_bayar');";
    if ($conn->query($sql) === TRUE) {
        $_SESSION['success'] = 'Data Pembayaran berhasil ditambahkan.';
    } else {
        $_SESSION['failed'] = 'Tambah data gagal, silahkan dicoba kembali.';
    }

    //mengembalikan ke data pembayaran add
    header("Location: adminDataPembayaranAdd.php");
    exit();
} else {
    $title = 'Tambah Pembayaran SPP';
    $active = 'pembayaran';

    date_default_timezone_set('Asia/Jakarta'); // Set the default timezone to Asia/Jakarta (WIB)
    $today = new DateTime('now');
    $todayFormatted = $today->format('Y-m-d');

    // mencari data siswa
    $siswa = array();
    $sql = "SELECT *
        FROM siswa;";
    $result = $conn->query($sql);
    if ($result->num_rows > 0) {
        // Fetch associative array
        $i = 0;
        while ($row = $result->fetch_assoc()) {
            $siswa[$i] = $row;
            $i++;
        }
    }
    // var_dump($siswa);

    include 'views/admin/pembayaran_add.php';
}

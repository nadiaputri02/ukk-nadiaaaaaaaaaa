<?php
require 'config.php';

session_start();

// mencari data kelas
$data = array();
$sql = "SELECT a.id_pembayaran AS id, b.username AS petugas, c.NIS AS nis, c.nama AS nama, a.tgl_bayar, a.jumlah_bayar 
        FROM pembayaran AS a
        INNER JOIN petugas AS b ON b.id_petugas = a.id_petugas
        INNER JOIN siswa AS c ON c.NIS = a.NIS;";
$result = $conn->query($sql);
if ($result->num_rows > 0) {
    // Fetch associative array
    $i = 0;
    while ($row = $result->fetch_assoc()) {
        $data[$i] = $row;
        $i++;
    }
}
// var_dump($data);

$title = 'Pembayaran SPP';
$active = 'pembayaran';
include 'views/admin/pembayaran.php';

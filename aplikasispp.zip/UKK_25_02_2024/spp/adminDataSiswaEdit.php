<?php
require 'config.php';
session_start();
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $nis = $_POST['nis'];
    $nama = $_POST['nama'];
    $kelas = $_POST['kelas'];

    // mengedit data
    $sql = "UPDATE siswa SET nama = '$nama', id_kelas = '$kelas' WHERE NIS = '$nis'";
    if ($conn->query($sql) === TRUE) {
        $_SESSION['success'] = 'Data siswa berhasil dirubah.';
    } else {
        $_SESSION['failed'] = 'Edit data gagal, silahkan dicoba kembali.';
    }
    // mengembalikan ke data siswa edit
    header("Location: adminDataSiswaEdit.php?id=$nis");
    exit();
} else {
    $title = 'Edit Siswa';
    $active = 'siswa';
    $id = $_GET['id'];

    // mencari detail data
    $data = array();
    $sql = "SELECT siswa.NIS, siswa.nama, siswa.id_kelas, concat(' [ ', kelas.nama_kelas, ' ] ', kelas.kompetensi_keahlian) AS kelas
        FROM siswa
        INNER JOIN kelas ON siswa.id_kelas = kelas.id_kelas
        WHERE siswa.NIS = '$id'";
    $result = $conn->query($sql);
    if ($result->num_rows > 0) {
        // Fetch associative array
        $i = 0;
        while ($row = $result->fetch_assoc()) {
            $data[$i] = $row;
            $i++;
        }
    }
    $data = $data[0];
    // var_dump($data);

    // mencari data kelas
    $kelas = array();
    $sql = "SELECT *
        FROM kelas
        ORDER BY nama_kelas DESC;";
    $result = $conn->query($sql);
    if ($result->num_rows > 0) {
        // Fetch associative array
        $i = 0;
        while ($row = $result->fetch_assoc()) {
            $kelas[$i] = $row;
            $i++;
        }
    }
    // var_dump($kelas);

    include 'views/admin/siswa_edit.php';
}

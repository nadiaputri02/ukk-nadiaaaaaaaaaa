<!-- ======= Sidebar ======= -->
<aside id="sidebar" class="sidebar">

  <ul class="sidebar-nav" id="sidebar-nav">
    <li class="nav-heading">Data</li>

    <li class="nav-item">
      <a class="nav-link <?php echo ($active == "pembayaran") ? '' : 'collapsed' ?>" href="/spp/adminDataPembayaran.php">
        <i class="ri ri-time-fill"></i>
        <span>Pembayaran SPP</span>
      </a>
    </li><!-- End Pembayaran SPP Page Nav -->

    <li class="nav-item">
      <a class="nav-link <?php echo ($active == "kelas") ? '' : 'collapsed' ?>" href="/spp/adminDataKelas.php">
        <i class="bi bi-door-open-fill"></i>
        <span>Kelas</span>
      </a>
    </li><!-- End Kelas Page Nav -->

    <li class="nav-item">
      <a class="nav-link <?php echo ($active == "siswa") ? '' : 'collapsed' ?>" href="/spp/adminDataSiswa.php">
        <i class="bi bi-people-fill"></i>
        <span>Siswa</span>
      </a>
    </li><!-- End Siswa Page Nav -->

  </ul>

</aside><!-- End Sidebar-->
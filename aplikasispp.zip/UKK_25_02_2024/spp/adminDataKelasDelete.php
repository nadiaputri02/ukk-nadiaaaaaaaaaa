<?php
session_start();
// Check if the user is logged in
if (!isset($_SESSION['username'])) {
    // echo 'logout';
    header("Location: admin.php");
    exit();
}
require 'config.php';

// mengambil GET Data
$id = $_GET['id'];

// menghapus data
$sql = "DELETE FROM kelas WHERE id_kelas = '$id';";
try {
    if ($conn->query($sql) === TRUE) {
        $_SESSION['success'] = 'Data kelas telah terhapus.';
    } else {
        $_SESSION['failed'] = 'Data kelas gagal terhapus, data kelas telah terhubung dengan data lain.';
    }
} catch (Exception $e) {
    $_SESSION['failed'] = 'Data kelas gagal terhapus, data kelas telah terhubung dengan data lain.';
}


// mengembalikan ke data kelas
header("Location: adminDataKelas.php");
exit();

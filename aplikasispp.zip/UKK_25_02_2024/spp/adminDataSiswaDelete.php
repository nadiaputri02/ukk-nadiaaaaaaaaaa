<?php
session_start();
// Check if the user is logged in
if (!isset($_SESSION['username'])) {
    // echo 'logout';
    header("Location: admin.php");
    exit();
}
require 'config.php';

// mengambil GET Data
$id = $_GET['id'];

// menghapus data
$sql = "DELETE FROM siswa WHERE NIS = '$id';";
try {
    if ($conn->query($sql) === TRUE) {
        $_SESSION['success'] = 'Data siswa telah terhapus.';
    } else {
        $_SESSION['failed'] = 'Data siswa gagal terhapus, data siswa telah terhubung dengan data lain.';
    }
} catch (Exception $e) {
    $_SESSION['failed'] = 'Data siswa gagal terhapus, data siswa telah terhubung dengan data lain.';
}


// mengembalikan ke data siswa
header("Location: adminDataSiswa.php");
exit();

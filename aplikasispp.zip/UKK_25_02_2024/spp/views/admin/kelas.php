<?php
// Check if the user is logged in
if (!isset($_SESSION['username'])) {
    // echo 'logout';
    header("Location: admin.php");
    exit();
}
?>
<?php include 'assets/header.php'; ?>
<?php include 'assets/topbar.php'; ?>
<?php include 'assets/sidebar_admin.php'; ?>
<main id="main" class="main">

    <div class="pagetitle">
        <h1>Kelas</h1>
        <nav>
            <ol class="breadcrumb">
                <li class="breadcrumb-item"><a href="/sekolah/adminDashboard.php">Home</a></li>
                <li class="breadcrumb-item active">Kelas</li>
            </ol>
        </nav>
    </div><!-- End Page Title -->

    <section class="section dashboard">
        <div class="col-12">
            <div class="card top-selling overflow-auto">

                <div class="card-body pb-0">
                    <h5 class="card-title">Data Kelas</h5>
                    <div class="col-12">
                        <?php if (isset($_SESSION['failed'])) : ?>
                            <div class="col-12 alert alert-danger alert-dismissible fade show mt-2" role="alert">
                                <?php echo ($_SESSION['failed']);
                                unset($_SESSION['failed']); ?>
                                <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
                            </div>
                        <?php endif; ?>
                        <?php if (isset($_SESSION['success'])) : ?>
                            <div class="col-12 alert alert-success alert-dismissible fade show mt-2" role="alert">
                                <?php echo ($_SESSION['success']);
                                unset($_SESSION['success']); ?>
                                <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
                            </div>
                        <?php endif; ?>
                    </div>
                    <div class="mb-2">
                        <form action="/spp/adminDataKelasAdd.php" method="get">
                            <button type="submit" class="btn btn-primary">Tambah Kelas</button>
                        </form>
                    </div>
                    <table class="table datatable">
                        <thead>
                            <tr>
                                <th scope="col">No</th>
                                <th scope="col">Kode Kelas</th>
                                <th scope="col">Nama Kelas</th>
                                <th scope="col">Kompetensi Keahlian</th>
                                <th scope="col">Aksi</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php $i = 1; ?>
                            <?php foreach ($data as $value) : ?>
                                <tr>
                                    <td><?= $i; ?></td>
                                    <td><?= $value['id_kelas']; ?></td>
                                    <td><?= $value['nama_kelas']; ?></td>
                                    <td><?= $value['kompetensi_keahlian']; ?></td>
                                    <td>
                                        <div class="row">
                                            <div class="col-6">
                                                <form action="/spp/adminDataKelasEdit.php" method="get" class="d-grid gap-2">
                                                    <input type="hidden" name="id" class="form-control" id="id" value="<?= $value['id_kelas']; ?>">
                                                    <button type="submit" class="btn btn-primary">Edit</button>
                                                </form>
                                            </div>
                                            <div class="col-6">
                                                <form action="/spp/adminDataKelasDelete.php" method="get" class="d-grid gap-2" onsubmit="return confirm('Apakah kamu yakin menghapusnya?');">
                                                    <input type="hidden" name="id" class="form-control" id="id" value="<?= $value['id_kelas']; ?>">
                                                    <button type="submit" class="btn btn-danger">Delete</button>
                                                </form>
                                            </div>
                                        </div>
                                    </td>
                                </tr>
                                <?php $i++; ?>
                            <?php endforeach; ?>
                        </tbody>
                    </table>

                </div>

            </div>
        </div>
    </section>

</main><!-- End #main -->


<?php include 'assets/footnote.php'; ?>
<?php include 'assets/footer.php'; ?>
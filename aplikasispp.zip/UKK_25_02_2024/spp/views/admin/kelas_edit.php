<?php
// Check if the user is logged in
if (!isset($_SESSION['username'])) {
    // echo 'logout';
    header("Location: admin.php");
    exit();
}
?>
<?php include 'assets/header.php'; ?>
<?php include 'assets/topbar.php'; ?>
<?php include 'assets/sidebar_admin.php'; ?>
<main id="main" class="main">

    <div class="pagetitle">
        <h1>Kelas</h1>
        <nav>
            <ol class="breadcrumb">
                <li class="breadcrumb-item"><a href="/spp/adminDataKelas.php">Kelas</a></li>
                <li class="breadcrumb-item active">Edit</li>
            </ol>
        </nav>
    </div><!-- End Page Title -->

    <section class="section dashboard">
        <div class="col-12">
            <div class="card top-selling overflow-auto">

                <div class="card-body pb-4">
                    <h5 class="card-title">Edit Kelas</h5>
                    <div class="col-12">
                        <?php if (isset($_SESSION['failed'])) : ?>
                            <div class="col-12 alert alert-danger alert-dismissible fade show mt-2" role="alert">
                                <?php echo ($_SESSION['failed']);
                                unset($_SESSION['failed']); ?>
                                <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
                            </div>
                        <?php endif; ?>
                        <?php if (isset($_SESSION['success'])) : ?>
                            <div class="col-12 alert alert-success alert-dismissible fade show mt-2" role="alert">
                                <?php echo ($_SESSION['success']);
                                unset($_SESSION['success']); ?>
                                <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
                            </div>
                        <?php endif; ?>
                    </div>

                    <form action="/spp/adminDataKelasEdit.php" method="post" class="row g-3 needs-validation" novalidate>
                        <div class="col-12">
                            <label for="kode" class="form-label"><b>Kode Kelas</b> <small>(Tidak dapat diedit)</small></label>
                            <div class="input-group has-validation">
                                <input type="text" placeholder="Kode Kelas" name="kode" class="form-control" id="kode" value="<?= $data['id_kelas']; ?>" readonly>
                                <div class="invalid-feedback">Silahkan Masukkan Kode Kelas.</div>
                            </div>
                        </div>
                        <div class="col-12">
                            <label for="nama" class="form-label"><b>Nama Kelas</b></label>
                            <div class="input-group has-validation">
                                <input type="text" placeholder="Nama Kelas" name="nama" class="form-control" id="nama" value="<?= $data['nama_kelas']; ?>" required>
                                <div class="invalid-feedback">Silahkan Masukkan Nama Kelas.</div>
                            </div>
                        </div>
                        <div class="col-12">
                            <label for="kompetensi" class="form-label"><b>Kompetensi Keahlian</b></label>
                            <div class="input-group has-validation">
                                <input type="text" placeholder="Kompetensi Keahlian Kelas" name="kompetensi" class="form-control" id="kompetensi" value="<?= $data['kompetensi_keahlian']; ?>" required>
                                <div class="invalid-feedback">Silahkan Masukkan Kompetensi Keahlian Kelas.</div>
                            </div>
                        </div>

                        <div class="col-12">
                            <button class="btn btn-primary w-100" type="submit">Simpan</button>
                        </div>
                    </form>

                </div>

            </div>
        </div>
    </section>

</main><!-- End #main -->


<?php include 'assets/footnote.php'; ?>
<?php include 'assets/footer.php'; ?>
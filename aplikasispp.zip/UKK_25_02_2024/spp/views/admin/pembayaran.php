<?php
// Check if the user is logged in
if (!isset($_SESSION['username'])) {
    // echo 'logout';
    header("Location: admin.php");
    exit();
}
?>
<?php include 'assets/header.php'; ?>
<?php include 'assets/topbar.php'; ?>
<?php include 'assets/sidebar_admin.php'; ?>
<main id="main" class="main">

    <div class="pagetitle">
        <h1>Pembayaran</h1>
        <nav>
            <ol class="breadcrumb">
                <li class="breadcrumb-item active">Pembayaran SPP</li>
            </ol>
        </nav>
    </div><!-- End Page Title -->

    <section class="section dashboard">
        <div class="col-12">
            <div class="card top-selling overflow-auto">

                <div class="card-body pb-0">
                    <h5 class="card-title">Data Pembayaran SPP</h5>
                    <div class="col-12">
                        <?php if (isset($_SESSION['failed'])) : ?>
                            <div class="col-12 alert alert-danger alert-dismissible fade show mt-2" role="alert">
                                <?php echo ($_SESSION['failed']);
                                unset($_SESSION['failed']); ?>
                                <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
                            </div>
                        <?php endif; ?>
                        <?php if (isset($_SESSION['success'])) : ?>
                            <div class="col-12 alert alert-success alert-dismissible fade show mt-2" role="alert">
                                <?php echo ($_SESSION['success']);
                                unset($_SESSION['success']); ?>
                                <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
                            </div>
                        <?php endif; ?>
                    </div>
                    <div class="mb-2">
                        <form action="/spp/adminDataPembayaranAdd.php" method="get">
                            <button type="submit" class="btn btn-primary">Tambah Pembayaran</button>
                        </form>
                    </div>
                    <table class="table datatable">
                        <thead>
                            <tr>
                                <th scope="col">No</th>
                                <th scope="col">Petugas</th>
                                <th scope="col">NIS</th>
                                <th scope="col">Nama Siswa</th>
                                <th scope="col">Tanggal Bayar</th>
                                <th scope="col">Jumlah</th>
                                <th scope="col">Aksi</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php $i = 1; ?>
                            <?php foreach ($data as $value) : ?>
                                <tr>
                                    <td><?= $i; ?></td>
                                    <td><?= $value['petugas']; ?></td>
                                    <td><?= $value['nis']; ?></td>
                                    <td><?= $value['nama']; ?></td>
                                    <td><?= $value['tgl_bayar']; ?></td>
                                    <td><?= $value['jumlah_bayar']; ?></td>
                                    <td>
                                        <div class="row">
                                            <div class="col-6">
                                                <form action="/spp/adminDataPembayaranEdit.php" method="get" class="d-grid gap-2">
                                                    <input type="hidden" name="id" class="form-control" id="id" value="<?= $value['id']; ?>">
                                                    <button type="submit" class="btn btn-primary">Edit</button>
                                                </form>
                                            </div>
                                            <div class="col-6">
                                                <form action="/spp/adminDataPembayaranDelete.php" method="get" class="d-grid gap-2" onsubmit="return confirm('Apakah kamu yakin menghapusnya?');">
                                                    <input type="hidden" name="id" class="form-control" id="id" value="<?= $value['id']; ?>">
                                                    <button type="submit" class="btn btn-danger">Delete</button>
                                                </form>
                                            </div>
                                        </div>
                                    </td>
                                </tr>
                                <?php $i++; ?>
                            <?php endforeach; ?>
                        </tbody>
                    </table>

                </div>

            </div>
        </div>
    </section>

</main><!-- End #main -->


<?php include 'assets/footnote.php'; ?>
<?php include 'assets/footer.php'; ?>
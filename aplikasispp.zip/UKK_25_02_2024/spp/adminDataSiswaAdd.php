<?php
require 'config.php';
session_start();
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $nis = $_POST['nis'];
    $nama = $_POST['nama'];
    $kelas = $_POST['kelas'];


    // mencari apakah nis telah terdaftar atau tidak
    $sql = "SELECT * FROM `siswa` WHERE NIS = '$nis';";
    $result = $conn->query($sql);
    if ($result->num_rows > 0) {
        $_SESSION['failed'] = 'S.';
    } else {
        // menambahkan data
        $sql = "INSERT INTO siswa (NIS, nama, id_kelas) VALUES ('$nis','$nama','$kelas');";
        if ($conn->query($sql) === TRUE) {
            $_SESSION['success'] = 'Data siswa berhasil ditambahkan.';
        } else {
            $_SESSION['failed'] = 'Tambah data gagal, silahkan dicoba kembali.';
        }
    }


    // mengembalikan ke data siswa add
    header("Location: adminDataSiswaAdd.php");
    exit();
} else {
    // mencari data kelas
    $kelas = array();
    $sql = "SELECT *
        FROM kelas
        ORDER BY nama_kelas DESC;";
    $result = $conn->query($sql);
    if ($result->num_rows > 0) {
        // Fetch associative array
        $i = 0;
        while ($row = $result->fetch_assoc()) {
            $kelas[$i] = $row;
            $i++;
        }
    }
    // var_dump($kelas);

    $title = 'Tambah Siswa';
    $active = 'siswa';
    include 'views/admin/siswa_add.php';
}

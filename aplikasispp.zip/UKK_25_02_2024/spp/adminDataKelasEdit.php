<?php
require 'config.php';
session_start();
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $kode = strtoupper($_POST['kode']);
    $nama = strtoupper($_POST['nama']);
    $kompetensi = $_POST['kompetensi'];

    // mencari apakah Kelas telah terdaftar atau tidak
    $sql = "SELECT * FROM `kelas` WHERE (nama_kelas = '$nama' AND kompetensi_keahlian = '$kompetensi');";
    $result = $conn->query($sql);
    if ($result->num_rows > 0) {
        $_SESSION['failed'] = 'Kelas yang sama telah terdaftar.';
    } else {
        // mengedit data
        $sql = "UPDATE kelas SET nama_kelas = '$nama', kompetensi_keahlian = '$kompetensi' WHERE id_kelas = '$kode';";
        if ($conn->query($sql) === TRUE) {
            $_SESSION['success'] = 'Data kelas berhasil dirubah.';
        } else {
            $_SESSION['failed'] = 'Edit data gagal, silahkan dicoba kembali.';
        }
    }
    // mengembalikan ke data kelas edit
    header("Location: adminDataKelasEdit.php?id=$kode");
    exit();
} else {
    if (isset($_GET['id'])) {
        $title = 'Edit Kelas';
        $active = 'kelas';
        $id = $_GET['id'];

        // mencari detail data
        $data = array();
        $sql = "SELECT * FROM kelas WHERE id_kelas = '$id';";
        $result = $conn->query($sql);
        if ($result->num_rows > 0) {
            // Fetch associative array
            $i = 0;
            while ($row = $result->fetch_assoc()) {
                $data[$i] = $row;
                $i++;
            }
        }
        $data = $data[0];
        include 'views/admin/kelas_edit.php';
    } else {
        // mengembalikan ke data kelas
        header("Location: adminDataKelas.php");
        exit();
    }
}

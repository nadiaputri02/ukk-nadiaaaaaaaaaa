<?php
require 'config.php';
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $username = $_POST['username'];
    $password = $_POST['password'];

    $sql = "SELECT * FROM petugas WHERE username = '$username' AND password = '$password'";
    $result = $conn->query($sql);
    $data = array();
    if ($result->num_rows > 0) {
        // Fetch associative array
        while ($row = $result->fetch_assoc()) {
            $data[] = $row;
        }
    }
    // var_dump($data);
    if (count($data) != 0) {
        session_start();
        $_SESSION['id'] = $data[0]['id_petugas'];
        $_SESSION['username'] = $data[0]['username'];
        $_SESSION['role'] = 'Admin';
        header("Location: adminDataKelas.php");
        exit();
    } else {
        $title = 'Login';
        $_SESSION['error'] = "Invalid Username or Password";
        include 'views/admin/login.php';
    }
} else {
    $title = 'Login';
    include 'views/admin/login.php';
}
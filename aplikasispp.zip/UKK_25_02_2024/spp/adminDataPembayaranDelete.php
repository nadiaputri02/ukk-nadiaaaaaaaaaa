<?php
session_start();
// Check if the user is logged in
if (!isset($_SESSION['username'])) {
    // echo 'logout';
    header("Location: admin.php");
    exit();
}
require 'config.php';

// mengambil GET Data
$id = $_GET['id'];

// menghapus data
$sql = "DELETE FROM pembayaran WHERE id_pembayaran = '$id';";
try {
    if ($conn->query($sql) === TRUE) {
        $_SESSION['success'] = 'Data pembayaran telah terhapus.';
    } else {
        $_SESSION['failed'] = 'Data pembayaran gagal terhapus, data pembayaran telah terhubung dengan data lain.';
    }
} catch (Exception $e) {
    $_SESSION['failed'] = 'Data pembayaran gagal terhapus, data pembayaran telah terhubung dengan data lain.';
}


// mengembalikan ke data pembayaran
header("Location: adminDataPembayaran.php");
exit();

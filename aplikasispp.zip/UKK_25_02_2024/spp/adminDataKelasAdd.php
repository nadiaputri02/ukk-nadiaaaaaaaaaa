<?php
require 'config.php';
session_start();
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $kode = strtoupper($_POST['kode']);
    $nama = strtoupper($_POST['nama']);
    $kompetensi = $_POST['kompetensi'];

    // mencari apakah Kelas telah terdaftar atau tidak
    $sql = "SELECT * FROM `kelas` WHERE id_kelas = '$kode' OR (nama_kelas = '$nama' AND kompetensi_keahlian = '$kompetensi');";
    $result = $conn->query($sql);
    if ($result->num_rows > 0) {
        $_SESSION['failed'] = 'Kelas yang sama telah terdaftar.';
    } else {
        // menambahkan data
        $sql = "INSERT INTO kelas (id_kelas, nama_kelas, kompetensi_keahlian ) VALUES ('$kode','$nama','$kompetensi');";
        if ($conn->query($sql) === TRUE) {
            $_SESSION['success'] = 'Data Kelas berhasil ditambahkan.';
        } else {
            $_SESSION['failed'] = 'Tambah data gagal, silahkan dicoba kembali.';
        }
    }
    // mengembalikan ke data kelas add
    header("Location: adminDataKelasAdd.php");
    exit();
} else {
    $title = 'Tambah Kelas';
    $active = 'kelas';
    include 'views/admin/kelas_add.php';
}

<?php
require 'config.php';

session_start();

// mencari data siswa
$data = array();
$sql = "SELECT siswa.NIS, siswa.nama, siswa.id_kelas, concat(' [ ', kelas.nama_kelas, ' ] ', kelas.kompetensi_keahlian) AS kelas
        FROM siswa
        INNER JOIN kelas ON siswa.id_kelas = kelas.id_kelas";
$result = $conn->query($sql);
if ($result->num_rows > 0) {
    // Fetch associative array
    $i = 0;
    while ($row = $result->fetch_assoc()) {
        $data[$i] = $row;
        $i++;
    }
}
// var_dump($data);

$title = 'Siswa';
$active = 'siswa';
include 'views/admin/siswa.php';

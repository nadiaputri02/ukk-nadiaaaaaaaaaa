<?php
require 'config.php';
session_start();
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $id_pembayaran = $_POST['id_pembayaran'];
    $siswa = $_POST['siswa'];
    $tgl_bayar = $_POST['tgl_bayar'];
    $jumlah_bayar = $_POST['jumlah_bayar'];
    // var_dump($id_pembayaran, $id_petugas, $siswa, $tgl_bayar, $jumlah_bayar);

    // mengedit data
    $sql = "UPDATE pembayaran SET NIS = '$siswa', tgl_bayar = '$tgl_bayar', jumlah_bayar = '$jumlah_bayar' WHERE id_pembayaran = $id_pembayaran;";
    if ($conn->query($sql) === TRUE) {
        $_SESSION['success'] = 'Data Pembayaran berhasil dirubah.';
    } else {
        $_SESSION['failed'] = 'Edit data gagal, silahkan dicoba kembali.';
    }

    // mengembalikan ke data kelas edit
    header("Location: adminDataPembayaranEdit.php?id=$id_pembayaran");
    exit();
} else {
    if (isset($_GET['id'])) {
        $title = 'Edit Pembayaran';
        $active = 'pembayaran';
        $id = $_GET['id'];

        // mencari detail data
        $data = array();
        $sql = "SELECT * FROM pembayaran 
                INNER JOIN siswa ON siswa.NIS = pembayaran.NIS 
                WHERE id_pembayaran = '$id';";
        $result = $conn->query($sql);
        if ($result->num_rows > 0) {
            // Fetch associative array
            $i = 0;
            while ($row = $result->fetch_assoc()) {
                $data[$i] = $row;
                $i++;
            }
        }
        $data = $data[0];

        // mencari data siswa
        $siswa = array();
        $sql = "SELECT *
        FROM siswa;";
        $result = $conn->query($sql);
        if ($result->num_rows > 0) {
            // Fetch associative array
            $i = 0;
            while ($row = $result->fetch_assoc()) {
                $siswa[$i] = $row;
                $i++;
            }
        }
        // var_dump($siswa);

        include 'views/admin/pembayaran_edit.php';
    } else {
        // mengembalikan ke data pembayaran
        header("Location: adminDataPembayaran.php");
        exit();
    }
}
